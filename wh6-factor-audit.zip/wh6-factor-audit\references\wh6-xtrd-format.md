# WH6 XTRD Format

`.XTRD` files in the verified WH6 formula folder are GB18030-compatible text files with XML-like sections. The audit tools care about:

- `<PARAM>`: zero or more default parameter rows such as `[N,1.000000,100.000000,14.000000]`.
- `<CODE>`: formula statements and drawing/style statements.
- Other sections such as `<DESCRIPTION>`, `<VERSION>`, `<EDITTIME>`, `<PROPERTY>`, and `<BRIEFDESCRIPTION>` are provenance metadata, not calculation inputs for the locked audit.

Output forms seen in the locked contract:

- Explicit named output: `K:SMA(RSV,M1,1);`
- Internal assignment: `RSV:=...;` (not exported by itself)
- Anonymous expression output: `CLOSE-REF(MA(CLOSE,20),11);`
- Style-decorated output: `2*(DIFF-DEA),COLORSTICK;`
- Sanitized or hash-named output: Chinese or duplicate labels mapped to stable `wh6_...` column names.

For this skill, `.XTRD` is the provenance source for the locked 198 columns. The skill does not auto-enroll additional `.XTRD` files.

---
name: wh6-factor-audit
description: Audit Wenhua WH6 factor datasets against a locked 198-column formula contract. Use when Codex needs to verify wh6_ columns, inspect .XTRD formula provenance, check WH6 formula/code hashes, compare future K-line datasets to the locked WH6 contract, or explain WH6 factor audit limits without appending or rewriting market data.
---

# WH6 Factor Audit

## Purpose

Use this skill to audit existing `wh6_` factor columns against the locked 198-column WH6 contract. Default to read-only verification: do not append columns, regenerate production datasets, or onboard new WH6 indicators unless the user explicitly asks for that mode.

The core invariant is:

```text
.XTRD formulas define what the locked 198 columns mean.
The Python audit script verifies source integrity, schema presence, and numeric anchors.
The skill reports evidence and limits instead of silently accepting or changing data.
```

## Default Workflow

1. Identify the user-provided dataset path, formula path, or both.
2. Run `scripts/wh6_audit.py summary` to confirm the bundled contract shape when useful.
3. If an `.XTRD` formula root is available, run `check-xtrd` against it.
4. If a CSV file or folder is available, run `check-csv` against it.
5. Add `--numeric-anchors` for spot/full-row checks of stable WH6 primitives when the CSV contains OHLCV fields.
6. Report exact evidence: missing columns, extra `wh6_` columns, hash mismatches, anchor mismatches, and unsupported areas.

Use examples:

```bash
python scripts/wh6_audit.py summary
python scripts/wh6_audit.py check-xtrd --xtrd-root "E:/path/to/wh6-formulas"
python scripts/wh6_audit.py check-csv --csv "E:/.../factor_a_10min.csv"
python scripts/wh6_audit.py check-csv --csv "E:/.../factor_data" --numeric-anchors --limit 5
```

## Contract

The locked contract is `references/wh6-locked-198-contract.json`.

It contains 198 entries copied from the verified WH6 audit evidence:

- `column`: locked `wh6_` column name.
- `indicator` and `output`: original audit mapping.
- `xtrd_relative_path`: formula file under a WH6 formula root.
- `param_text` and `code_text`: extracted `.XTRD` parameter and code blocks.
- `param_sha256`, `code_sha256`, and `xtrd_file_sha256`: drift checks.
- `output_kind`: `explicit_named` or `anonymous_or_sanitized`.

Do not treat other `.XTRD` files as automatically in scope. This skill's default mode audits only the locked 198 columns.

## References

Read these only when needed:

- `references/wh6-xtrd-format.md`: `.XTRD` text structure and output naming.
- `references/wh6-function-semantics.md`: supported WH6 primitive semantics and numeric anchor limits.
- `references/wh6-audit-policy.md`: what claims are allowed after each audit level.

## Reporting Rules

Use careful wording:

- Say "source contract matches" only when `check-xtrd` passes.
- Say "CSV schema matches the locked 198 columns" only when `check-csv` reports no missing/extra `wh6_` columns.
- Say "numeric anchors match" only when `--numeric-anchors` passes.
- Do not claim every cell of all 198 indicators has been fully reinterpreted unless a full interpreter or equivalent verifier was actually run.
- If the user asks to add new WH6 indicators, treat that as a separate onboarding task and do not modify this locked contract silently.

# WH6 Audit Policy

Default mode is read-only.

Do not:

- Append `wh6_` columns to source CSVs.
- Rewrite market data.
- Add newly discovered `.XTRD` indicators to the locked contract.
- Present unsupported proprietary WH6 functions as fully independently verified.

Allowed claims by evidence level:

- Contract summary only: "The bundled contract defines 198 locked WH6 columns."
- `check-xtrd` pass: "The provided formula folder matches the locked formula sources for the 198 columns."
- `check-csv` pass: "The CSV schema contains the locked 198 WH6 columns with no missing or extra WH6 columns."
- `check-csv --numeric-anchors` pass: "Implemented numeric anchor families match within tolerance."

When there is a mismatch, identify the exact class:

- Missing locked column.
- Extra `wh6_` column outside the locked contract.
- `.XTRD` file missing.
- `.XTRD` code or parameter hash changed.
- Numeric anchor mismatch.
- Unsupported or unimplemented formula family.

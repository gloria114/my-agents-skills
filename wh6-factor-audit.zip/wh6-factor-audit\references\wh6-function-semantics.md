# WH6 Function Semantics

The bundled numeric anchor verifier implements stable primitives used to catch silent drift:

- `REF(X,N)`: shift by `N` rows.
- `MA(X,N)`: rolling simple average with a full `N`-row window.
- `EMA(X,N)`: exponential moving average with `alpha = 2 / (N + 1)`, recursive form.
- `SMA(X,N,M)`: Wenhua-style recursive smoothing with `alpha = M / N`; after initialization, missing inputs keep the previous state.
- `SUM(X,N)`: rolling sum; `SUM(X,0)` is cumulative.
- `HHV(X,N)` / `LLV(X,N)`: rolling max/min.
- `STD(X,N)`: rolling population standard deviation (`ddof=0`).
- `AVEDEV(X,N)`: rolling mean absolute deviation from the rolling mean.
- `COUNT(cond,N)`: rolling count of true values.
- `IF` / `IFELSE`: vectorized conditional selection.

Anchor coverage currently includes columns from MA, EMA, DEMA, SMA, MACD, KD, KDJ, RSI, ATR, BIAS, ROC, BOLL, CCI, DMI, OBV increment, VWMA, Z-SCORE, and ADTM families.

Unsupported or partial areas should be reported as limits, not failures:

- Wenhua proprietary market fields or functions such as `CCL`, `CJLVOL`, `SETTLE`, `FORCAST`, `VOLATILITY`, `SAR`, and `SAR1`.
- Drawing, color, text, sound, icon, and style commands.
- Full all-cell proof for all 198 columns unless a complete WH6 interpreter is added and run.
